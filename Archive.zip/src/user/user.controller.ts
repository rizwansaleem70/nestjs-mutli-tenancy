import { Controller, Get, Post, Req } from '@nestjs/common';
import { UserService } from './user.service';
import { Request } from 'express';

@Controller('users')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Get()
  async findAll(@Req() req: Request) {
    console.log('request', req.headers);
    return await this.userService.getAllUsers();
  }

  @Post()
  async create(@Req() req: Request) {
    return await this.userService.createUser(req.body.name, req.body.email);
  }
}
