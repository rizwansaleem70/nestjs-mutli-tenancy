import { DataSource } from 'typeorm';
import { User } from './entities/user.entity';
import { Request } from 'express';
import { Inject } from '@nestjs/common';

export class UserService {
  private readonly dataSource: DataSource;

  constructor(@Inject('REQUEST') private readonly req: Request) {
    this.dataSource = req['tenantConnection'];
    if (!this.dataSource) {
      throw new Error('Tenant connection is not available');
    }
  }

  async createUser(name: string, email: string) {
    console.log('this.dataSource.', this.dataSource.options);
    const userRepo = this.dataSource.getRepository(User);
    const user = userRepo.create({ name, email });
    return await userRepo.save(user);
  }

  async getAllUsers() {
    return await this.dataSource.getRepository(User).find();
  }
}
