import { Module, Scope } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { User } from './entities/user.entity';

@Module({
  imports: [TypeOrmModule.forFeature([User])],
  controllers: [UserController],
  providers: [
    {
      provide: UserService,
      useClass: UserService,
      scope: Scope.REQUEST, // Request-scoped service to access tenant connection
    },
  ],
  exports: [UserService],
})
export class UserModule {}
