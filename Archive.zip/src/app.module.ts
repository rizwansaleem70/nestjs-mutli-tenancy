import { MiddlewareConsumer, Module, RequestMethod } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TenantModule } from './tenant/tenant.module';
import { UserModule } from './user/user.module';
import { TenantMiddleware } from './tenant/tenant.middleware';
import { dataSourceOptions } from './data-source-options';
const { ...options } = dataSourceOptions;

@Module({
  imports: [
    TypeOrmModule.forRoot({
      autoLoadEntities: true,
      ...options,
    }),
    TenantModule,
    UserModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(TenantMiddleware)
      .exclude(
        { path: 'tenants', method: RequestMethod.ALL }, // Exclude all routes inside TenantModule
        { path: 'tenants/(.*)', method: RequestMethod.ALL }, // Exclude subroutes
      )
      .forRoutes('*'); // Apply middleware to all other routes
  }
}
