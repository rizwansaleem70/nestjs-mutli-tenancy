import { Controller, Post, Param } from '@nestjs/common';
import { TenantService } from './tenant.service';

@Controller('tenants')
export class TenantController {
  constructor(private readonly tenantService: TenantService) {}

  @Post('create/:name')
  async createTenant(@Param('name') name: string) {
    return await this.tenantService.getTenantConnection(name);
  }
}
