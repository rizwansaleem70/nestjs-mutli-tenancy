import { Injectable, NestMiddleware, Inject, forwardRef } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { TenantService } from './tenant.service';
import { DataSource } from 'typeorm';

@Injectable()
export class TenantMiddleware implements NestMiddleware {
  constructor(
    @Inject(forwardRef(() => TenantService))
    private readonly tenantService: TenantService,
  ) {}

  async use(req: Request, res: Response, next: NextFunction) {
    const tenantName = req.headers['x-tenant-id'] as string;

    if (!tenantName) {
      return res.status(400).json({ message: 'Tenant ID is required' });
    }

    try {
      const tenantConnection: DataSource =
        await this.tenantService.getTenantConnection(tenantName);
      // Ensure tenant database has tables
      await tenantConnection.synchronize();
      req['tenantConnection'] = tenantConnection;
      next();
    } catch (error) {
      return res.status(400).json({ message: error.message });
    }
  }
}
