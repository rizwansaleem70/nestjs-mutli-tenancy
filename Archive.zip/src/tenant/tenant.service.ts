import { Injectable } from '@nestjs/common';
import { User } from 'src/user/entities/user.entity';
import { DataSource, DataSourceOptions } from 'typeorm';

@Injectable()
export class TenantService {
  private tenants: { [key: string]: DataSource } = {}; // Store tenant connections

  constructor(private readonly masterDataSource: DataSource) {}

  async getTenantConnection(tenantId: string): Promise<DataSource> {
    if (this.tenants[tenantId]) {
      return this.tenants[tenantId];
    }

    const tenantDbName = `tenant_${tenantId}`;

    // Create the tenant database if it does not exist
    await this.masterDataSource.query(
      `CREATE DATABASE IF NOT EXISTS ${tenantDbName}`,
    );

    const tenantDataSourceOptions: DataSourceOptions = {
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: 'password',
      database: tenantDbName, // Use the newly created tenant DB
      entities: [User],
      migrations: [__dirname + '/../database/migrations/*{.ts,.js}'],
      synchronize: false, // We will use migrations instead
    };

    const tenantConnection = new DataSource(tenantDataSourceOptions);
    await tenantConnection.initialize();

    // **Run Migrations for the New Tenant Database**
    await tenantConnection.runMigrations();

    this.tenants[tenantId] = tenantConnection;
    return tenantConnection;
  }
}
