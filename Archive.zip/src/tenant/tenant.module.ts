import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TenantService } from './tenant.service';
import { TenantController } from './tenant.controller';
import { Tenant } from './entities/tenant.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Tenant])],
  controllers: [TenantController],
  providers: [TenantService], // Ensure the service is provided
  exports: [TenantService], // Make it available for other modules
})
export class TenantModule {
  // configure(consumer: MiddlewareConsumer) {
  //   consumer
  //     .apply(TenantMiddleware)
  //     .forRoutes({ path: 'users/*', method: RequestMethod.ALL });
  // }
}
